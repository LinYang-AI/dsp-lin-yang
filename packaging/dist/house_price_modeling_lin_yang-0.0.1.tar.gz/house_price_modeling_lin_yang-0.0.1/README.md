# This is a package creation practice

This package provides built standar scaler, one hot encoder, and model for making prediction of house prices.
